<footer id="footer">
    <div class="inner">
        <ul class="copyright">
                <li>&copy; Claudia Carvalho & Vito Melchionna.</li>
                <li>Design: Claudia Carvalho & Vito Melchionna.</li>
        </ul>
    </div>
</footer>
</div>    
    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/skel.min.js"></script>
    <script src="assets/js/util.js"></script>
    <!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
    <script src="assets/js/main.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>