<?php	
echo '
<header id="header">
        <div class="inner">
    <!--Header-->           
		  <a href="index.php" class="logo">
            <span class="symbol"><img src="images/c_logo.svg" alt="" /></span><span class="title">Event Agenda</span>
		  </a>
		  <!-- Nav -->
		  <nav>
			<ul>
				<li><a href="#menu">Menu</a></li>
            </ul>
		  </nav>
        </div>
    </header>'
?>