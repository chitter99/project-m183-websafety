<?php


    $titel = $_POST["titel"];
    $titelfoto = $_POST["titelfoto"];
    $adresse = $_POST["adresse"];
    $beschreibung = $_POST["beschreibung"];
    $startdatum = $_POST["startdate"];
    $enddatum = $_POST["enddate"];


    $_SESSION['titelfoto'] = '';
    $_SESSION['titel'] = '';
