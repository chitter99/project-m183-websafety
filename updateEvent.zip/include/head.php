<?php
session_start(); 
?>
<!DOCTYPE HTML>
<html>
<head>
     <title>Event Agenda</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/main.css"/>
    <link rel="stylesheet" href="assets/css/meinEigenes.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body onload="initialize()">
<!-- Wrapper -->
<div id="wrapper">       
<?php include 'include/header.php';?>
<?php include 'menu.php';  ?>    