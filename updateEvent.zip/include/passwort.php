<?php
    echo 'Passwörter sind nicht identisch!!!'
?>